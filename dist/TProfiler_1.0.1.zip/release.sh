#!/bin/sh

rm -rf ../../dist/*
mvn -f ../../pom.xml clean package
cp ../../COPYING.txt ../../README .
cp ../../src/main/resources/profile.properties .
zip -r -xprofile.properties -xrelease.sh ../../dist/TProfiler_1.0.1.zip *

